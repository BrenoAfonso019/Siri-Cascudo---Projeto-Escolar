import { StyleSheet, Text, View, Pressable } from 'react-native'
import { router } from 'expo-router'
import { MaterialIcons } from '@react-native-vector-icons/material-icons'
import { Fontes } from '@/constants/Fontes'
import { Cores } from '@/constants/Cores'

export function Cabecalho({titulo}){

    const sair = () => {
        router.replace('/')
    }

    return(
        <View style={estilos.conteiner}>
            <Text style={titulo == 'Siri Cascudo' ? estilos.textoLogo : estilos.texto}>{titulo}</Text>

            {/* Renderização condicional */}
            {titulo !== 'Siri Cascudo' && (
                <Pressable 
                    style={estilos.logout}
                    onPress={sair}
                >
                    <MaterialIcons name="logout" size={Fontes.grande2} color={Cores.secundariaClara} />
                </Pressable> 
            )}

        </View>
    )
}

const estilos = StyleSheet.create({
    conteiner: {
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: Cores.primaria,
        height: 60,
    },
    texto: {
        color: Cores.secundariaClara,
        fontSize: Fontes.grande1,
        fontFamily: Fontes.logo,
    },
    textoLogo: {
        color: Cores.secundariaClara,
        fontSize: Fontes.grande2,
        fontFamily: Fontes.logo,
    },
    logout: {
        position: 'absolute',
        right: 10
    }
})