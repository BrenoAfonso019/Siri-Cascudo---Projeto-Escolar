import { StyleSheet, Text, Pressable, View, ImageBackground } from 'react-native'
import { SafeAreaView } from 'react-native-safe-area-context'
import { MaterialIcons } from '@react-native-vector-icons/material-icons'
import { Cabecalho } from '@/components/Cabecalho'
import { Cores } from '@/constants/Cores'
import { Fontes } from '@/constants/Fontes' 

export default function Home() {
  return (
    <SafeAreaView style={estilos.conteiner}>
      <Cabecalho titulo={'Cardápio'} />

      {/* Esta View com flex: 1 e justifyContent: center alinha tudo no meio verticalmente */}
      <View style={estilos.conteudo}>

        {/* Bloco de Títulos */}
        <View style={estilos.headerTexto}>
          <Text style={estilos.subtitulo}>O que vai ser hoje?</Text>
          <Text style={estilos.descricao}>Escolha uma categoria para mergulhar!</Text>
        </View>

        {/* Card 1: Hambúrgueres */}
        <Pressable 
          style={estilos.card}
          android_ripple={{ color: Cores.primariaClara }}
        >
          <ImageBackground 
            source={require('@/assets/images/layout/hamburguer.jpg')} // Insira o caminho da imagem
            style={estilos.imagemCard}
            imageStyle={{ borderRadius: 15 }}
          >
            <View style={estilos.overlay}>
              <View style={estilos.infoCard}>
                <Text style={estilos.rotuloCard}>Hambúrgueres</Text>
                <Text style={estilos.textoDescricaoCard}>Receitas artesanais da casa</Text>
              </View>
              <View style={estilos.botaoCirculo}>
                <MaterialIcons name="chevron-right" size={24} color={Cores.subtitulo} />
              </View>
            </View>
          </ImageBackground>
        </Pressable>

        {/* Card 2: Bebidas */}
        <Pressable 
          style={estilos.card}
          android_ripple={{ color: Cores.primariaClara }}
        >
          <ImageBackground 
            source={require('@/assets/images/layout/bebidas.jpg')} // Insira o caminho da imagem
            style={estilos.imagemCard}
            imageStyle={{ borderRadius: 15 }}
          >
            <View style={estilos.overlay}>
              <View style={estilos.infoCard}>
                <Text style={estilos.rotuloCard}>Bebidas</Text>
                <Text style={estilos.textoDescricaoCard}>Refrescantes e saborosas</Text>
              </View>
              <View style={estilos.botaoCirculo}>
                <MaterialIcons name="chevron-right" size={24} color={Cores.subtitulo} />
              </View>
            </View>
          </ImageBackground>
        </Pressable>

        {/* Card 3: Porções */}
        <Pressable 
          style={estilos.card}
          android_ripple={{ color: Cores.primariaClara }}
        >
          <ImageBackground 
            source={require('@/assets/images/layout/porcoes.jpg')} // Insira o caminho da imagem
            style={estilos.imagemCard}
            imageStyle={{ borderRadius: 15 }}
          >
            <View style={estilos.overlay}>
              <View style={estilos.infoCard}>
                <Text style={estilos.rotuloCard}>Porções</Text>
                <Text style={estilos.textoDescricaoCard}>Deliciosas e compartilháveis</Text>
              </View>
              <View style={estilos.botaoCirculo}>
                <MaterialIcons name="chevron-right" size={24} color={Cores.subtitulo} />
              </View>
            </View>
          </ImageBackground>
        </Pressable>

      </View>
    </SafeAreaView>
  )
}

const estilos = StyleSheet.create({
  conteiner: {
    flex: 1,
    backgroundColor: Cores.primariaEscura,
  },
  // Alinha o conteúdo vertical e horizontalmente no centro da tela
  conteudo: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 20,
  },
  headerTexto: {
    width: '100%',
    marginBottom: 20,
  },
  subtitulo: {
    fontFamily: Fontes.logo,
    fontSize: Fontes.grande1,
    color: Cores.primariaClara,
  },
  descricao: {
    fontFamily: Fontes.baseRegular,
    fontSize: Fontes.medio1,
    color: Cores.primariaEscura,
    marginTop: 4,
  },
  // Estrutura dos Cards
  card: {
    width: '100%',
    height: 120,
    marginVertical: 10,
    borderRadius: 15,
    borderWidth: 2,
    borderColor: Cores.secundaria,
    overflow: 'hidden',
  },
  imagemCard: {
    width: '100%',
    height: '100%',
    justifyContent: 'center',
  },
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.35)', // Escurece levemente a foto para destacar os textos
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
  },
  infoCard: {
    flex: 1,
  },
  rotuloCard: {
    color: '#FFFFFF',
    fontFamily: Fontes.logo,
    fontSize: Fontes.grande1,
    fontWeight: 'bold',
  },
  textoDescricaoCard: {
    color: '#FFFFFF',
    fontFamily: Fontes.baseRegular,
    fontSize: Fontes.pequeno,
    marginTop: 2,
  },
  botaoCirculo: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: Cores.secundaria,
    justifyContent: 'center',
    alignItems: 'center',
  },
})