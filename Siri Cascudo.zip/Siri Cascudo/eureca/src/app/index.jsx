import { useState } from 'react'
import { router } from 'expo-router'
import { Text, StyleSheet, Pressable, Alert, Image } from 'react-native'
import { SafeAreaView } from 'react-native-safe-area-context'
import { MaterialIcons } from '@react-native-vector-icons/material-icons' // Ajustado para o padrão do Expo
import { Cores } from '@/constants/Cores'
import { Fontes } from '@/constants/Fontes'

export default function Index() {

  const verificarUsuario = () => {
    router.push('/home')
  }

  const abrirSobre = () => {
    router.push('/(tabs)/Sobre')
  }

  return (
    <SafeAreaView style={estilos.conteiner}>

      <Image 
        style={estilos.fundo}
        source={require('@/assets/images/layout/fundo.png')}
      />

      <Text style={estilos.titulo}>Siri</Text>
      <Text style={estilos.subtitulo}>Cascudo</Text>

      <Pressable 
        style={estilos.botao}
        android_ripple={{color: Cores.primariaClara}}
        onPress={verificarUsuario}
      >
        <MaterialIcons name="menu" size={Fontes.grande1} color={Cores.primariaClara} />
        <Text style={estilos.rotulo}> Ver Cardápio </Text>
      </Pressable>

      <Pressable 
        style={estilos.botao}
        android_ripple={{color: Cores.primariaClara}}
        onPress={abrirSobre}
      >
        <MaterialIcons name="info" size={Fontes.grande1} color={Cores.primariaClara} />
        <Text style={estilos.rotulo}> Sobre </Text>
      </Pressable>

    </SafeAreaView>
  )
}

const estilos = StyleSheet.create({
  conteiner: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: Cores.primariaEscura,
  },
  titulo: {
    marginTop: -40,
    marginBottom: 10,
    fontFamily: Fontes.logo,
    fontSize: Fontes.extraGrande,
    color: Cores.titulo,
  },
  subtitulo: {
    marginBottom: 350,
    fontFamily: Fontes.logo,
    fontSize: Fontes.subtitulo,
    color: Cores.subtitulo,
  },
  botao: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: Cores.primariaEscura,
    borderColor: Cores.primariaClara,
    height: 50,
    width: 300,        
    borderWidth: 1,
    borderRadius: 5,
    marginVertical: 10,
  },
  rotulo: {
    color: Cores.secundariaClara,
    fontFamily: Fontes.baseRegular,
    fontSize: Fontes.medio1,
    marginEnd: 10,
  },
  fundo: {
    position: 'absolute',
    height: '100%',
    width: '100%',
    objectFit: 'fill',    
  }
})