export const Cores = {
  primariaClara: '#B2EBF2',     
  primaria: '#00BCD4',         
  primariaEscura: '#00838F',    
  secundariaClara: '#FFECB3',   
  secundaria: '#FFC107',        
  secundariaEscura: '#FFA000',  
  terciaria: '#FF5252',        
  titulo: '#ff0202',            
  subtitulo: '#ff0202',         
}
