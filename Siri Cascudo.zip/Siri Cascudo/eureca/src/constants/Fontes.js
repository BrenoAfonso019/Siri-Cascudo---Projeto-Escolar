export const Fontes = {
    baseLight: 'MontserratLight',
    baseRegular: 'MontserratRegular',
    baseBold: 'MontserratBold',
    logo: 'BubblegumSans-Regular',
    pequeno: 12,
    medio1: 16,
    medio2: 20,
    grande1: 28,
    grande2: 32,
    subtitulo: 40,
    extraGrande: 80,
}